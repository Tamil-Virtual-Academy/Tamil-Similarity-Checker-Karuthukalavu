<style>
.field{ width:100%; }
input[type=text]{ max-width:400px; }
</style>
<div id="feedback" class="form clear">

	<h4>கருத்துக்களை பதியவும்</h4>
	<p>இத்தளத்திலுள்ள சேவையைப் பற்றிய தங்கள் கருத்துக்களை வரவேற்கிறோம். உங்கள் மேலான கருத்துக்களை, கீழ்கண்ட உரைப்பெட்டியில் நிரப்பி தளத்தில் பதியவும். இந்த பயன்பாட்டின் கருத்துக்களவு முடிவுகளிலோ அல்லது பயன்பாட்டின் இயக்கத்திலோ ஏதாவது குறைகளையோ பிழைகளையோ தாங்கள் கண்டெடுத்தாலும், அவற்றை எங்களுக்கு தயை கூர்ந்து கீழ்கண்ட படிவத்தின் மூலமாக தெரியப்படுத்தவும். இச்சேவையை மேம்படுத்த தங்களின் பின்னூட்டங்கள் மிக்க பயனுள்ளதாக அமையும். இத்தளத்தை பயன்படுத்தியதற்கு நன்றி!</p>


	<div class="field">
		<label>பெயர்: *</label><br /> <input type="text" name="name" id="peyar" />
	</div>
	<div class="field">
		<label>மின்னஞ்சல்:</label><br /> <input type="text" name="email" id="anjal" />
	</div>
	<div class="field">
		<label>கருத்து: *</label><br />
		<textarea class="comment large" name="comment" id="karuthu"></textarea>
	</div>
	<div class="field msg" id="result" style="display:none;">
	தயவுசெய்து உங்கள் கருத்தையும் பெயரையும் உள்ளிட்டு பிறகு பதிவு செய்யவும்.
	</div>
	<div class="field">
		<input id="btnAddCmt" type="button" class="button" value="பதிவு செய்" /> <input
			id="btnCmtReset" type="button" class="button" value="அழி"  />
	</div>

</div>