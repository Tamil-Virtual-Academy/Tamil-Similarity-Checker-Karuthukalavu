<?php 

global $cfg;
$cfg = new stdClass();

$cfg->server = '';
$cfg->uid = '';
$cfg->pwd = '';
$cfg->db = '';

?>
